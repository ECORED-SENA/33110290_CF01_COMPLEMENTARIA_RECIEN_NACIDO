function ExecuteScript(strId)
{
  switch (strId)
  {
      case "6R16KWuJYAw":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

